# AminData WebView Android project

- Native Android WebView for https://amindata.com.ng/mobile
- Onboarding screens shown on first launch
- Register: https://amindata.com.ng/mobile/register/
- Recovery: https://amindata.com.ng/mobile/recovery/
- Optional biometric/device-credential app unlock, enabled from the welcome screen
- GitHub Actions workflow builds a debug APK artifact

## Important biometric limitation
The biometric feature is an app-unlock gate. It does not replace the AminData website's username/password login or create a server-side biometric credential. The website's existing WebView cookies keep the web session. True fingerprint-based account login requires a secure backend/API token enrollment and authentication flow.

## Build
Push the project to GitHub, then run the `Build AminData APK` workflow under Actions. Download the APK from the workflow artifact.
