package com.amindata.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var appRoot: LinearLayout
    private var onboardingPage = 0
    private var showingOnboarding = false
    private var showingEntry = false

    private val homeUrl = "https://amindata.com.ng/mobile"
    private val registerUrl = "https://amindata.com.ng/mobile/register/"
    private val recoveryUrl = "https://amindata.com.ng/mobile/recovery/"
    private val trustedHost = "amindata.com.ng"
    private val green = Color.rgb(5, 139, 70)
    private val darkGreen = Color.rgb(0, 91, 49)
    private val paleGreen = Color.rgb(232, 248, 239)
    private val ink = Color.rgb(23, 42, 35)
    private val muted = Color.rgb(103, 122, 113)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        appRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        createWebView()

        val prefs = getSharedPreferences("amindata_app", MODE_PRIVATE)
        if (prefs.getBoolean("fingerprint_enabled", false)) {
            authenticateWithBiometric {
                continueStartup(savedInstanceState)
            }
        } else {
            continueStartup(savedInstanceState)
        }
    }


    private fun continueStartup(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("amindata_app", MODE_PRIVATE)
        if (savedInstanceState != null && savedInstanceState.getBoolean("web_open", false)) {
            showWebView()
            webView.restoreState(savedInstanceState)
        } else if (prefs.getBoolean("onboarding_done", false)) {
            showEntryScreen()
        } else {
            showOnboarding(0)
        }
    }

    private fun authenticateWithBiometric(onSuccess: () -> Unit) {
        val manager = BiometricManager.from(this)
        val canAuth = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            getSharedPreferences("amindata_app", MODE_PRIVATE).edit().putBoolean("fingerprint_enabled", false).apply()
            Toast.makeText(this, "Fingerprint bai samuwa ba a wannan wayar. Ka shiga da password.", Toast.LENGTH_LONG).show()
            onSuccess()
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onSuccess()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (errorCode == BiometricPrompt.ERROR_USER_CANCELED || errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                    finish()
                } else {
                    Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            override fun onAuthenticationFailed() {
                Toast.makeText(this@MainActivity, "Ba a gane fingerprint ba. Sake gwadawa.", Toast.LENGTH_SHORT).show()
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock AminData")
            .setSubtitle("Yi amfani da fingerprint ko screen lock na wayarka")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progressTintList = ColorStateList.valueOf(green)
            visibility = View.GONE
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val scheme = uri.scheme ?: return true
                    if (scheme == "https" && uri.host == trustedHost) return false
                    if (scheme == "http" || scheme == "https" || scheme == "tel" || scheme == "mailto" || scheme == "whatsapp") {
                        return try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                        } catch (_: Exception) {
                            Toast.makeText(this@MainActivity, "Ba a iya buɗe wannan link ba", Toast.LENGTH_SHORT).show(); true
                        }
                    }
                    return true
                }
                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                    if (request?.isForMainFrame == true) errorText.visibility = View.VISIBLE
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    errorText.visibility = View.GONE
                    CookieManager.getInstance().flush()
                }
            }
        }
        errorText = TextView(this).apply {
            text = "Ba a iya haɗawa da AminData ba. Ka duba internet sannan ka sake gwadawa.\n\nDanna nan domin sake buɗewa."
            textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY)
            setPadding(32, 32, 32, 32); setBackgroundColor(Color.WHITE); visibility = View.GONE
            setOnClickListener { visibility = View.GONE; webView.reload() }
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 5))
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(errorText, LinearLayout.LayoutParams(-1, -1))
        webContainer = root
    }

    private lateinit var webContainer: LinearLayout

    private fun showWebView(url: String? = null) {
        showingOnboarding = false; showingEntry = false
        appRoot.removeAllViews(); appRoot.addView(webContainer, LinearLayout.LayoutParams(-1, -1))
        setContentView(appRoot)
        if (url != null) webView.loadUrl(url)
        else if (webView.url == null) webView.loadUrl(homeUrl)
    }

    private fun showOnboarding(page: Int) {
        showingOnboarding = true; showingEntry = false; onboardingPage = page.coerceIn(0, 2)
        appRoot.removeAllViews(); appRoot.setPadding(dp(24), dp(16), dp(24), dp(22))
        appRoot.orientation = LinearLayout.VERTICAL
        appRoot.setBackgroundColor(Color.WHITE)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "AminData"; textSize = 21f; setTextColor(darkGreen); typeface = Typeface.DEFAULT_BOLD }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        val skip = textButton("Skip") { finishOnboarding() }
        top.addView(skip)
        appRoot.addView(top)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        }
        val illustration = TextView(this).apply {
            text = when (onboardingPage) { 0 -> "📱"; 1 -> "⚡"; else -> "🛡️" }
            textSize = 76f; gravity = Gravity.CENTER
            background = rounded(paleGreen, 34)
        }
        content.addView(illustration, LinearLayout.LayoutParams(-1, dp(230)).apply { bottomMargin = dp(34) })
        val heading = when (onboardingPage) {
            0 -> "Welcome to AminData"
            1 -> "Fast & Easy Payments"
            else -> "Secure Transactions"
        }
        val description = when (onboardingPage) {
            0 -> "Your trusted platform for data, airtime, TV, electricity bills and more."
            1 -> "Buy data, airtime and pay bills in just a few taps. No stress, no hassle."
            else -> "Your security matters. Use your account password and transaction PIN to help keep your account safe."
        }
        val title = TextView(this).apply {
            text = heading; textSize = 27f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(14))
        }
        val body = TextView(this).apply {
            text = description; textSize = 16f; setTextColor(muted); gravity = Gravity.CENTER
            setLineSpacing(dp(5).toFloat(), 1f); setPadding(dp(8), 0, dp(8), 0)
        }
        content.addView(title); content.addView(body)
        appRoot.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val dots = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        for (i in 0..2) {
            val dot = View(this).apply { background = rounded(if (i == onboardingPage) green else Color.LTGRAY, 20) }
            dots.addView(dot, LinearLayout.LayoutParams(dp(if (i == onboardingPage) 24 else 8), dp(8)).apply { marginEnd = dp(6) })
        }
        appRoot.addView(dots, LinearLayout.LayoutParams(-1, dp(28)).apply { bottomMargin = dp(18) })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (onboardingPage > 0) buttons.addView(actionButton("Back", false) { showOnboarding(onboardingPage - 1) }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(10) })
        val nextLabel = if (onboardingPage == 2) "Get Started" else "Next"
        buttons.addView(actionButton(nextLabel, true) {
            if (onboardingPage < 2) showOnboarding(onboardingPage + 1) else finishOnboarding()
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        appRoot.addView(buttons)
        setContentView(appRoot)
    }

    private fun showEntryScreen() {
        showingOnboarding = false; showingEntry = true
        appRoot.removeAllViews(); appRoot.setPadding(dp(26), dp(24), dp(26), dp(28))
        appRoot.orientation = LinearLayout.VERTICAL; appRoot.gravity = Gravity.CENTER
        appRoot.setBackgroundColor(Color.WHITE)
        val logo = TextView(this).apply {
            text = "A\nAminData"; textSize = 34f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(darkGreen); gravity = Gravity.CENTER; setLineSpacing(0f, 0.9f)
        }
        val tagline = TextView(this).apply { text = "...stay connected always..."; textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER }
        val welcome = TextView(this).apply {
            text = "Welcome!"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink); gravity = Gravity.CENTER; setPadding(0, dp(42), 0, dp(10))
        }
        val intro = TextView(this).apply {
            text = "Log in to your account or create a new AminData account to get started."
            textSize = 15f; setTextColor(muted); gravity = Gravity.CENTER
        }
        appRoot.addView(logo, LinearLayout.LayoutParams(-1, dp(110)))
        appRoot.addView(tagline)
        appRoot.addView(welcome)
        appRoot.addView(intro, LinearLayout.LayoutParams(-1, dp(70)))
        appRoot.addView(actionButton("Create Account", true) { showWebView(registerUrl) }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(24) })
        appRoot.addView(actionButton("Login", false) { showWebView(homeUrl) }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        val fingerprintPrefs = getSharedPreferences("amindata_app", MODE_PRIVATE)
        val fingerprintButton = TextView(this).apply {
            text = if (fingerprintPrefs.getBoolean("fingerprint_enabled", false)) "Fingerprint lock is enabled ✓" else "Enable fingerprint unlock"
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(green); gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(8))
            setOnClickListener {
                val available = BiometricManager.from(this@MainActivity).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                if (available != BiometricManager.BIOMETRIC_SUCCESS) {
                    Toast.makeText(this@MainActivity, "Ka fara saita fingerprint ko screen lock a Settings na wayarka.", Toast.LENGTH_LONG).show()
                } else {
                    fingerprintPrefs.edit().putBoolean("fingerprint_enabled", true).apply()
                    text = "Fingerprint lock is enabled ✓"
                    Toast.makeText(this@MainActivity, "Fingerprint unlock ya kunna. Za a tambaye ka idan ka sake buɗe app.", Toast.LENGTH_LONG).show()
                }
            }
        }
        appRoot.addView(fingerprintButton, LinearLayout.LayoutParams(-1, dp(48)))
        val recovery = TextView(this).apply {
            text = "Forgot Password?"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(green); gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(8))
            setOnClickListener { showWebView(recoveryUrl) }
        }
        appRoot.addView(recovery, LinearLayout.LayoutParams(-1, dp(48)))
        val privacy = TextView(this).apply { text = "Fast  •  Secure  •  Reliable"; textSize = 13f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(20), 0, 0) }
        appRoot.addView(privacy)
        setContentView(appRoot)
    }

    private fun finishOnboarding() {
        getSharedPreferences("amindata_app", MODE_PRIVATE).edit().putBoolean("onboarding_done", true).apply()
        showEntryScreen()
    }

    private fun actionButton(label: String, primary: Boolean, onClick: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) Color.WHITE else green)
        background = rounded(if (primary) green else Color.WHITE, 16)
        if (!primary) background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat(); setStroke(dp(1), green) }
        setOnClickListener { onClick() }
    }

    private fun textButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(green)
        setPadding(dp(14), dp(12), dp(4), dp(12)); setOnClickListener { onClick() }
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onBackPressed() {
        when {
            showingOnboarding && onboardingPage > 0 -> showOnboarding(onboardingPage - 1)
            showingOnboarding -> finishOnboarding()
            showingEntry -> super.onBackPressed()
            ::webView.isInitialized && webView.canGoBack() -> webView.goBack()
            else -> showEntryScreen()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::webView.isInitialized && !showingOnboarding && !showingEntry) {
            outState.putBoolean("web_open", true); webView.saveState(outState)
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) { webView.stopLoading(); webView.destroy() }
        super.onDestroy()
    }
}
